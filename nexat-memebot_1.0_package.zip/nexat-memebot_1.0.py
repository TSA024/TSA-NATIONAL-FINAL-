import tkinter as tk
from tkinter import scrolledtext
import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer, GPT2Config

class ChatbotApp:
    def __init__(self, master):
        self.master = master
        master.title("NEXAT-Memebot")
        
        # Set the background color to medium-dark grey
        master.configure(bg='#333333')  # Hex code for medium-dark grey

        # Load GPT-2 model and tokenizer
        model_name = 'gpt2'
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_name)
        self.model = GPT2LMHeadModel.from_pretrained(model_name, config=GPT2Config.from_pretrained(model_name))

        # Check if GPU is available and move the model to GPU
        if torch.cuda.is_available():
            self.model.cuda()

        # GUI components
        self.conversation_text = scrolledtext.ScrolledText(master, width=146, height=40, bg='#333333', fg='white', insertbackground='white')  # Set text color, cursor color, and background color
        self.user_input_entry = tk.Entry(master, width=60, bg='white', fg='black', insertbackground='black')  # Set text color and cursor color
        self.send_button = tk.Button(master, text="Send", command=self.send_user_input, bg='#333333', fg='white')  # Set button color

        # Set placeholder for user_input_entry
        self.user_input_entry.insert(0, "User Input here...")
        self.user_input_entry.bind("<FocusIn>", self.on_entry_focus_in)
        self.user_input_entry.bind("<FocusOut>", self.on_entry_focus_out)

        # Place GUI components
        self.conversation_text.grid(row=0, column=0, columnspan=2, padx=10, pady=10)
        self.user_input_entry.grid(row=1, column=0, padx=10, pady=10)
        self.send_button.grid(row=1, column=1, padx=10, pady=10)

    def gpt2_chatbot(self, prompt):
        input_ids = self.tokenizer.encode(prompt, return_tensors='pt')

        # Generate a response using the GPT-2 model with a smaller max_length
        output = self.model.generate(
            input_ids,
            max_length=80,  # Adjust this value to control response length
            temperature=0.01,
            num_beams=10,
            no_repeat_ngram_size=1,
            pad_token_id=self.tokenizer.eos_token_id,
            attention_mask=torch.ones(input_ids.shape),
            do_sample=True
        )

        # Decode the generated response
        response = self.tokenizer.decode(output[0], skip_special_tokens=True)

        return response

    def send_user_input(self):
        user_input = self.user_input_entry.get()
        self.conversation_text.insert(tk.END, f"User: {user_input}\n")

        # Get the chatbot's response
        chatbot_response = self.gpt2_chatbot(user_input)

        # Display the chatbot's response with white text color
        self.conversation_text.insert(tk.END, f"NEXAT-Memebot: {chatbot_response}\n")
        self.conversation_text.yview(tk.END)  # Scroll to the bottom

        # Clear the user input entry
        self.user_input_entry.delete(0, tk.END)
        # Reset placeholder if the entry is empty
        if not user_input:
            self.user_input_entry.insert(0, "User Input here...")

    def on_entry_focus_in(self, event):
        # Remove placeholder text when the entry gets focus
        if self.user_input_entry.get() == "User Input here...":
            self.user_input_entry.delete(0, tk.END)

    def on_entry_focus_out(self, event):
        # Restore placeholder text if the entry loses focus and is empty
        if not self.user_input_entry.get():
            self.user_input_entry.insert(0, "User Input here...")

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatbotApp(root)
    root.geometry("1200x720")  # Set the main window size
    root.mainloop()
